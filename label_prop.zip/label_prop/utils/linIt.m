function a = linIt(A)
% function a = linIt(A)
%	a = A(:);
	a = A(:);
end
