% this function computes the pdf of the GMM evaluated at each image pixel position

% INPUT
% im        the input image
% model     the GMM model fitted. model.mu contains the means of the
%           component Gaussian. model.Sigma contains the covariance matrices, and
%           model.weights contains the priors

% OUTPUT    pdf value evaluated at each pixel position
% Md. Alimoor Reza, November 2013
function [ MM ] = compute_likelihood_gmm(im, model, k)

    sz_im = size(im);
    r = im(:,:,1);
    g = im(:,:,2);
    b = im(:,:,3);
    data = [r(:) g(:) b(:)];
    
    MM = zeros([sz_im(1:2) k], 'double');
    % use covariance matrix for each mixture
    for gi=1:k
        tmp = mvnpdf(data, model.mu(:,gi)', model.Sigma(:,:,gi));
        %tmp = loggausspdf(data', model.mu(:,gi), model.Sigma(:,:,gi));
        tmp = model.weight(gi)*tmp;
        MM(:,:,gi) = reshape(tmp, sz_im(1:2));
        
    end


end

